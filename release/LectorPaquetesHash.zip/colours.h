
#ifndef _colours
#define _colours

#include <stdio.h>  

#define COLOUR_RED "\e[31m"  
#define COLOUR_B_RED "\e[31;1m"  
#define COLOUR_GREEN "\e[32m"  
#define COLOUR_B_GREEN "\e[32;1m"  
#define COLOUR_YELLOW "\e[33m"  
#define COLOUR_B_YELLOW "\e[33;1m"  
#define COLOUR_BLUE "\e[34m"  
#define COLOUR_B_BLUE "\e[34;1m"  
#define COLOUR_MAGENTA "\e[35m"  
#define COLOUR_BRIGHT "\e[1m"  
#define COLOUR_CYAN "\e[36m"  
#define COLOUR_NONE "\e[m"  

#endif
