
#ifndef _colours
#define _colours

#define COLOUR_RED "\e[m"  
#define COLOUR_B_RED "\e[m"  
#define COLOUR_GREEN "\e[m"  
#define COLOUR_B_GREEN "\e[m"  
#define COLOUR_YELLOW "\e[m"  
#define COLOUR_B_YELLOW "\e[m"  
#define COLOUR_BLUE "\e[m"  
#define COLOUR_B_BLUE "\e[m"    
#define COLOUR_MAGENTA "\e[m"    
#define COLOUR_BRIGHT "\e[m"    
#define COLOUR_CYAN "\e[m"  
#define COLOUR_NONE "\e[m"  

#endif
